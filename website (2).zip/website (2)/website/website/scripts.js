window.addEventListener('scroll', function() {
    const nav = document.getElementById('navbar');
    if (window.scrollY > 0) {
        nav.style.background = 'rgba(75, 0, 130, 0.8)';
    } else {
        nav.style.background = 'transparent';
    }
});

function initMap() {
    const location = { lat: 35.6764, lng: 139.839478 };
    const map = new google.maps.Map(document.getElementById('map'), {
        zoom: 8,
        center: location
    });
    const marker = new google.maps.Marker({
        position: location,
        map: map
    });
}
